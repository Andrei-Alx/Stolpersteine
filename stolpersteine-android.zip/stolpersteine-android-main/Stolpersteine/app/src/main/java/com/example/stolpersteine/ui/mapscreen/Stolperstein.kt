package com.example.stolpersteine.ui.mapscreen

import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.clustering.ClusterItem

data class Stolperstein(
    val id: Int,
    val city: String,
    val officialStone: Boolean,
    val address: String,
    val name: String,
    val dateOfBirth: String,
    val dateOfPassing: String,
    val placeOfPassing: String,
    val reasonOfPassing: String,
    val gender: String,
    val photo: String,
    val url: String,
    val niodUrl: String,
    val mapUrl: String,
    val location: Location
) : ClusterItem {
    override fun getPosition(): LatLng {
        return LatLng(location.lat, location.long)
    }

    override fun getTitle(): String {
        return name
    }

    override fun getSnippet(): String {
        return address
    }

    override fun getZIndex(): Float? {
        return 0f
    }
}
