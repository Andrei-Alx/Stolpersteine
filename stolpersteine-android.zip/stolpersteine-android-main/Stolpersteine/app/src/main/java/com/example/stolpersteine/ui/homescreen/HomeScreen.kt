package com.example.stolpersteine.ui.homescreen

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.navigation.NavController
import com.example.stolpersteine.R
import com.example.stolpersteine.ui.theme.BrightRed

@Composable
fun HomeScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        HeaderImage()
        Spacer(modifier = Modifier.height(16.dp))
        DescriptionSection()
        Spacer(modifier = Modifier.height(16.dp))
        ButtonSection(navController)
    }
}

@Composable
fun HeaderImage() {
    Image(
        modifier = Modifier
            .width(291.dp)
            .height(53.dp),
        painter = painterResource(id = R.drawable.newheader),
        contentDescription = "Stolperstein",
        contentScale = ContentScale.FillBounds
    )
}

@Composable
fun PlaqueImage() {
    Image(
        modifier = Modifier
            .width(393.dp)
            .height(397.dp),
        painter = painterResource(id = R.drawable.stolperstein),
        contentDescription = "image description",
        contentScale = ContentScale.FillBounds
    )
}

@Composable
fun DescriptionSection() {
    val description = "We are students from Fontys and this is a project for Stichting 18 September about Stolpersteine."

    Box {
        PlaqueImage()
        Column(
            modifier = Modifier
                .graphicsLayer(
                    translationY = (800).toFloat(),
                )
                .padding(4.dp)
                .zIndex(2f)
        ) {
            Text(
                text = "WHO ARE WE?",
                color = Color.White,
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.ExtraBold),
                fontSize = 19.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = description,
                color = Color.White
            )
        }
    }
}

@Composable
fun ButtonSection(navController: NavController) {
    Column {
        Button(
            onClick = { navController.navigate("search") }, modifier = Modifier.width(310.dp).height(60.dp),
            colors = ButtonDefaults.outlinedButtonColors(containerColor =  Color(BrightRed.value), contentColor = Color.White)

        ) {
            Text("HISTORY")
        }
        Spacer(modifier = Modifier.height(10.dp))
        Button(onClick = { navController.navigate("scan") }, modifier = Modifier.width(310.dp).height(60.dp),
            colors = ButtonDefaults.outlinedButtonColors(containerColor =  Color(BrightRed.value), contentColor = Color.White)
        ) {
            Text("LIGHT A CANDLE")
        }
    }
}