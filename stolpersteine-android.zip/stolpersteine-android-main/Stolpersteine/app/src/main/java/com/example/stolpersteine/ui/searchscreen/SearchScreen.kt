package com.example.stolpersteine.ui.searchscreen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import com.example.stolpersteine.R
import com.example.stolpersteine.ui.theme.BrightRed
import com.example.stolpersteine.ui.theme.StolpersteineTheme
import androidx.navigation.compose.rememberNavController

@Composable
fun SearchScreen(navController: NavHostController) {
    // Sample data: replace these with your image resources or URLs
    val images = listOf(
        R.drawable.image1,
        R.drawable.image2,
        R.drawable.image3,
        R.drawable.image4
    )

    // Map of image descriptions
    val imageDescriptions = mapOf(
        R.drawable.image1 to "Richard Kirby (Australia), member of the Good Offices Commission, on the subject of the documents of the so-called 'Renville' " + "agreement in Tj. Priok. to draw. NI 8028",
        R.drawable.image2 to "The leader of the republican delegation Mr. Saitono, addresses the meeting at the conclusion of the 'Renville' agreement in Tj. Priok, 17-1-1948. NI 8018",
        R.drawable.image3 to "Abdul Kadir Widjojoatmodjo speaks during the conclusion of the 'Renville' agreement in Tj. Priok, 17-1-1948. NI 8022",
        R.drawable.image4 to "The captain of U.S.S. 'Renville' addresses the meeting at the conclusion of the so-called 'Renville' agreement in Tj. Priok, 17-1-1948. NI 8026"
    )

    var selectedImage by remember { mutableStateOf<Int?>(null) }
    var showDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Text header
        Text(
            text = "About oorlogsbronnen.nl \n" +
                    "Oorlogsbronnen.nl constitutes a central online gateway to original sources, information, and knowledge about World War II. Oorlogsbronnen.nl utilizes these collections and links events, locations, individuals, and themes.",
            textAlign = TextAlign.Center,
            color = Color.Black,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Search box with white background
        OutlinedTextField(
            value = "",
            onValueChange = {},
            placeholder = { Text("Search") },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
                .background(Color.White) // Set the background color to white
        )

        // Carousel with scrollable images
        ImageCarousel(images = images, onImageClick = { image ->
            selectedImage = image
            showDialog = true
        })

        Text(
            text = "The second World War\n" +
                    "this is what happened on January 17th.",
            textAlign = TextAlign.Center,
            color = Color.Black,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 16.dp)
        )


        ButtonWithColor(navController)

        // Description Dialog
        if (showDialog) {
            selectedImage?.let { image ->
                DescriptionDialog(
                    description = imageDescriptions[image] ?: "No description available"
                ) { showDialog = false }
            }
        }
    }
}

@Composable
fun ImageCarousel(images: List<Int>, onImageClick: (Int) -> Unit) {
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
    ) {
        items(images) { image ->
            Image(
                painter = painterResource(id = image),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .width(150.dp)
                    .height(200.dp)
                    .clip(shape = MaterialTheme.shapes.medium)
                    .padding(8.dp)
                    .clickable { onImageClick(image) }
            )
        }

    }
}

@Composable
fun ButtonWithColor(navController: NavController) {
    Button(
        onClick = {
            navController.navigate("timeline")
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp)
            .padding(top = 16.dp),
        colors = ButtonDefaults.buttonColors(Color(BrightRed.value), contentColor = Color.White)
    ) {
        Text(text = "TimeLine", color = Color.White)
    }
}

@Composable
fun DescriptionDialog(description: String, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("History") },
        text = { Text(description) },
        confirmButton = {
            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .size(48.dp)
            ) {
                Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
            }
        },
    )
}

@Preview(showBackground = true)
@Composable
fun PreviewSearchScreen() {
    StolpersteineTheme {
        val navController = rememberNavController()
        SearchScreen(navController)
    }
}
