package com.example.stolpersteine.ui.stonescreen

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun StoneScreen(navController: NavController){
    Text(text = "STONE SCREEN", color = Color.Red, fontSize = 19.sp)
}