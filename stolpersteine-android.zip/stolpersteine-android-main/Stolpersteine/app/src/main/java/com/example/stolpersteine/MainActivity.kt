package com.example.stolpersteine

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.compose.rememberNavController
import com.example.stolpersteine.ui.navbar.NavBar
import com.example.stolpersteine.ui.navbar.NavItem
import com.example.stolpersteine.ui.navbar.Navigating
import com.example.stolpersteine.ui.theme.LightGold
import com.example.stolpersteine.ui.theme.StolpersteineTheme
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices

class MainActivity : ComponentActivity() {
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient

    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)

        setContent {
            StolpersteineTheme {
                val navController = rememberNavController()
                Scaffold (bottomBar = {
                    NavBar(items = listOf(
                        NavItem(
                            name = "Home",
                            route = "home",
                            icon = Icons.Default.Home
                        ),
                        NavItem(
                            name = "Map",
                            route = "map",
                            icon = Icons.Default.LocationOn
                        ),
                        NavItem(
                            name = "Search",
                            route = "search",
                            icon = Icons.Default.Search
                        ),
                    ), navController = navController, modifier = Modifier, onItemClickListener = {navController.navigate(it.route)} )
                }, containerColor = Color(LightGold.value)){
                    Navigating(navController = navController, fusedLocationProviderClient)//TODO change things
                }
            }
        }
    }
}