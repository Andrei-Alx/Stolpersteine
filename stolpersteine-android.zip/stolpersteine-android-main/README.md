# Stolpersteine android


## Description

Welcome to the Stolperstainer Android app! This application is designed to enhance your experience with Stolperstainer, providing a seamless way to discover these historical markers. The app incorporates features such as maps for easy exploration, a timeline card for historical context, and a carousel to showcase the evolution of associated pictures.


## Visuals
<div style="display:flex;">
<img src="https://i.ibb.co/jLWNfhq/image-1.png" width="589" height="1278">
<img src="https://i.ibb.co/NxPq9GN/image2.png" width="589" height="1278">
<img src="https://i.ibb.co/4J5gyjQ/image3.png" width="589" height="1278">





</div>


## Usage

**Short description of the important parts of the code:**

**fetchStones** function:

Uses Gson for JSON parsing.
Reads a JSON file (eindhovenstones.json) from the raw resources, representing data about Stolpersteines in Eindhoven.
Deserializes the JSON data into a list of Stolperstein objects.
Prints the list of Stolpersteines to the console.
bitmapDescriptorFromVector function:

Takes a vector drawable resource ID and converts it into a BitmapDescriptor for use in Google Maps.
Uses BitmapDescriptorFactory.fromBitmap() to create the BitmapDescriptor.
MapScreen composable function:

Takes in a NavController, FusedLocationProviderClient, and a list of Stolperstein objects.
Initiates the process of fetching Stolpersteines using fetchStones.
Manages the current location and camera position state.
Displays a Google Map using a custom composable MyGoogleMap and handles location updates through a GPS icon.
MyGoogleMap composable function:

Configures various map properties and UI settings.
Uses the GoogleMap composable from the Maps Compose API to display the map.
Utilizes clustering for grouping markers on the map.
Includes a custom GPS icon button (GpsIconButton) for triggering location updates.
GpsIconButton composable function:

Displays a button with a GPS icon.
The button triggers the onIconClick callback, likely intended to update the user's current location on the map.

This code is written in Kotlin and is part of an Android app using Jetpack Compose, a modern UI toolkit for building native Android applications. Let's break down the important parts of the code:

Imports: The code includes various AndroidX Compose and material design library imports, as well as imports for custom resources and themes.

**SearchScreen Function:**

This function is annotated with @Composable, indicating that it defines a composable UI element.
It receives a NavHostController as a parameter, presumably for navigation purposes.
Defines sample data for images and their descriptions.
Uses state variables (selectedImage and showDialog) to manage the state of the selected image and whether the description dialog should be shown.
Utilizes a Column composable to arrange its child elements vertically.
Contains text elements, an outlined search box, an image carousel, a button, and a description dialog.
ImageCarousel Function:

An @Composable function that creates a horizontal carousel of images using a LazyRow.
It takes a list of image resource IDs and a callback for when an image is clicked.
Each image is displayed in a clickable Image composable within the LazyRow.
ButtonWithColor Function:

Another @Composable function that creates a button with a specified background color (BrightRed), text, and navigation behavior when clicked.
It uses the NavController to navigate to a destination named "timeline" when the button is clicked.
DescriptionDialog Function:

A composable function for displaying a simple AlertDialog with a title ("History"), text (image description), and a close button.
It takes a description and a callback function to dismiss the dialog.
PreviewSearchScreen Function:

A composable preview function for the SearchScreen, wrapped in a StolpersteineTheme.
It uses rememberNavController to simulate a navigation controller for the preview.





[DEMO Video](https://drive.google.com/file/d/1ZTShZVCegluGSZXL5QEm2AVTt7gT7O5U/view?usp=sharing)




## Project status

 ![Finish](https://png2.cleanpng.com/sh/86f6d6940ae9ee1a3b1903b8aff1899b/L0KzQYm3VMIzN6R0j5H0aYP2gLBuTfNwdaF6jNd7LXnmf7B6TfZqdpp4gJ91aX7oPbr1g710fJDog595aHB3f7j5ggBpgV46edZsY0TlSYGBhcI5Pl89Tac6MkG1RIK8UsQ1OWg8SqM5M0a3PsH1h5==/kisspng-computer-icons-finish-line-inc-stock-photography-5adcc4b908e286.8551212415244177210364.png) 



  
